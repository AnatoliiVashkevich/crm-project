"""main.py - FastAPI routes only. Data access lives in database.py."""
import os
import logging
from collections import defaultdict
from decimal import Decimal
from pathlib import Path

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles

import database as db

log = logging.getLogger("crm")
BASE_DIR = Path(__file__).parent

CORS_ORIGINS = [
    o.strip() for o in os.getenv(
        "CORS_ORIGINS",
        "http://localhost:5500,http://127.0.0.1:5500,http://localhost:8000,http://127.0.0.1:8000",
    ).split(",") if o.strip()
]

app = FastAPI(title="Field Service CRM API")
app.add_middleware(CORSMiddleware, allow_origins=CORS_ORIGINS, allow_credentials=False,
                   allow_methods=["*"], allow_headers=["*"])

# ---------- what the client may write (anything else -> 400) ----------
FIELDS = {
    "profile":  {"company_name", "phone", "email", "business_address", "payment_details",
                 "default_hourly_rate", "logo_url"},
    "clients":  {"name", "phone", "email", "street", "city", "state", "zip", "notes"},
    "projects": {"name", "street", "city", "state", "zip", "estimate_mode", "estimate_description",
                 "estimate_fixed", "estimate_rate", "estimate_hours"},
    "visits":   {"visit_date", "planned_work", "time_spent", "status", "image_urls"},
    "receipts": {"amount", "store", "category", "receipt_date", "billable", "image_urls"},
    "invoices": {"status", "paid_date", "invoice_date", "description"},
}
# parent keys: accepted on create only, never on PATCH
PARENTS = {"projects": {"client_id"}, "visits": {"project_id"}, "receipts": {"project_id", "visit_id"}}
REQUIRED_PARENT = {"projects": ["client_id"], "visits": ["project_id"], "receipts": ["project_id"]}
CREATABLE = {"clients", "projects", "visits", "receipts"}   # invoices are created from a visit (Step 5)
DELETABLE = {"clients", "projects", "visits", "receipts", "invoices"}

NULL_IF_EMPTY = {"estimate_mode", "estimate_fixed", "estimate_rate", "estimate_hours", "paid_date", "visit_id"}
ZERO_IF_EMPTY = {"time_spent", "amount", "default_hourly_rate"}


def money(x) -> Decimal:
    return Decimal(str(x or 0))


def clean(body: dict, allowed: set[str], entity: str) -> dict:
    rejected = sorted(set(body) - allowed)
    if rejected:
        raise HTTPException(400, f"Fields not allowed for {entity}: {', '.join(rejected)}")
    out = {}
    for k, v in body.items():
        if isinstance(v, str):
            v = v.strip() if k not in ("planned_work", "notes", "description", "estimate_description") else v
        if v == "" and k in NULL_IF_EMPTY:
            v = None
        elif v in ("", None) and k in ZERO_IF_EMPTY:
            v = 0
        out[k] = v
    return out


def safe(fn, *args, **kwargs):
    """Run a DB call; turn database errors into a readable 400."""
    try:
        return fn(*args, **kwargs)
    except HTTPException:
        raise
    except Exception as e:
        log.exception("Database error")
        raise HTTPException(400, f"Database error: {e}")


def need(table: str, row_id: str) -> dict:
    row = safe(db.get_row, table, row_id)
    if not row:
        raise HTTPException(404, f"{table[:-1].capitalize()} not found")
    return row


def unpaid_total(invoices: list[dict]) -> float:
    return float(sum((money(i["total"]) for i in invoices if i["status"] == "Unpaid"), Decimal(0)))


# ---------- My Profile ----------
@app.get("/api/profile")
def get_profile():
    return need("profile", 1)


@app.patch("/api/profile")
def patch_profile(body: dict):
    data = clean(body, FIELDS["profile"], "profile")
    return safe(db.update_row, "profile", 1, data)


# ---------- Navigation tree: Client -> Project -> Visits (+ debt badges) ----------
@app.get("/api/tree")
def get_tree():
    clients = sorted(db.fetch_all("clients", "id,name,phone"), key=lambda c: (c["name"] or "").lower())
    projects = db.fetch_all("projects", "id,client_id,name,created_at")
    visits = db.fetch_all("visits", "id,project_id,visit_date,status")
    unpaid = db.fetch_all("invoices", "id,project_id,client_id,total", status="Unpaid")

    debt_project, debt_client = defaultdict(Decimal), defaultdict(Decimal)
    for inv in unpaid:
        debt_project[inv["project_id"]] += money(inv["total"])
        debt_client[inv["client_id"]] += money(inv["total"])

    visits_by_project = defaultdict(list)
    for v in sorted(visits, key=lambda v: v["visit_date"]):
        visits_by_project[v["project_id"]].append(v)

    projects_by_client = defaultdict(list)
    for p in sorted(projects, key=lambda p: p["created_at"], reverse=True):
        projects_by_client[p["client_id"]].append({
            "id": p["id"], "name": p["name"],
            "debt": float(debt_project[p["id"]]),
            "visits": visits_by_project[p["id"]],
        })

    return [{
        "id": c["id"], "name": c["name"],
        "debt": float(debt_client[c["id"]]),
        "projects": projects_by_client[c["id"]],
    } for c in clients]


# ---------- Detail views (what the workspace shows) ----------
@app.get("/api/clients/{client_id}")
def client_detail(client_id: str):
    client = need("clients", client_id)
    invoices = db.select_where("invoices", "client_id", client_id, order="invoice_date", desc=True)
    return {"client": client, "invoices": invoices, "debt": unpaid_total(invoices)}


@app.get("/api/projects/{project_id}")
def project_detail(project_id: str):
    project = need("projects", project_id)
    visits = db.select_where("visits", "project_id", project_id, order="visit_date")
    invoices = db.select_where("invoices", "project_id", project_id, order="invoice_date", desc=True)
    return {
        "project": project,
        "client": need("clients", project["client_id"]),
        "visits": visits,
        "receipts": db.select_where("receipts", "project_id", project_id, order="receipt_date", desc=True),
        "invoices": invoices,
        # canceled visits are excluded from total hours
        "total_hours": float(sum((money(v["time_spent"]) for v in visits if v["status"] != "Canceled"), Decimal(0))),
        "debt": unpaid_total(invoices),
    }


@app.get("/api/visits/{visit_id}")
def visit_detail(visit_id: str):
    visit = need("visits", visit_id)
    project = need("projects", visit["project_id"])
    return {
        "visit": visit,
        "project": project,
        "client": need("clients", project["client_id"]),   # name/phone/email/address flow from the client card
        "invoices": db.select_where("invoices", "visit_id", visit_id, order="invoice_date", desc=True),
        "receipts": db.select_where("receipts", "visit_id", visit_id, order="receipt_date", desc=True),
    }


# ---------- Generic CRUD: create / PATCH (auto-save) / delete ----------
@app.post("/api/{entity}")
def create(entity: str, body: dict):
    if entity not in CREATABLE:
        raise HTTPException(404, "Unknown or non-creatable entity")
    data = clean(body, FIELDS[entity] | PARENTS.get(entity, set()), entity)
    missing = [p for p in REQUIRED_PARENT.get(entity, []) if not data.get(p)]
    if missing:
        raise HTTPException(400, f"Missing: {', '.join(missing)}")
    if entity == "visits" and not data.get("visit_date"):
        data["visit_date"] = db.today_local()
    if entity == "receipts" and not data.get("receipt_date"):
        data["receipt_date"] = db.today_local()
    return safe(db.insert_row, entity, data)


@app.patch("/api/{entity}/{row_id}")
def patch(entity: str, row_id: str, body: dict):
    if entity not in FIELDS or entity == "profile":
        raise HTTPException(404, "Unknown entity")
    data = clean(body, FIELDS[entity], entity)
    old = need(entity, row_id)

    if entity == "invoices" and "status" in data:       # [ Unpaid ] <-> [ Paid ] in one tap
        if data["status"] == "Paid":
            data["paid_date"] = data.get("paid_date") or old.get("paid_date") or db.today_local()
        else:
            data["paid_date"] = None

    row = safe(db.update_row, entity, row_id, data)

    if "image_urls" in data:                            # photo removed in UI -> delete file from Storage
        removed = set(old.get("image_urls") or []) - set(data["image_urls"] or [])
        db.delete_photos(removed)
    return row


@app.delete("/api/{entity}/{row_id}")
def delete(entity: str, row_id: str):
    if entity not in DELETABLE:
        raise HTTPException(404, "Unknown entity")
    need(entity, row_id)
    urls = db.collect_photo_urls(entity, row_id)        # collect first: DB rows cascade, files don't
    safe(db.delete_row, entity, row_id)
    db.delete_photos(urls)
    return {"status": "deleted"}


# ---------- Frontend (put index.html, styles.css, api.js, app.js in ./static) ----------
@app.get("/")
def index():
    return FileResponse(BASE_DIR / "static" / "index.html")


app.mount("/static", StaticFiles(directory=BASE_DIR / "static"), name="static")
