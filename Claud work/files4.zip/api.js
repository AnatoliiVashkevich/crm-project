// api.js - talks to the backend. No DOM rendering except the save indicator.
const API_BASE = "/api";
let saveTimer;

function setSave(state, msg) {
  const el = document.getElementById("saveState");
  clearTimeout(saveTimer);
  if (state === "saving") {
    el.textContent = "Saving...";
    el.className = "save saving";
  } else if (state === "saved") {
    el.textContent = "Saved ✓";
    el.className = "save saved";
    saveTimer = setTimeout(() => { el.textContent = ""; }, 2000);
  } else {
    el.textContent = "Error: " + msg;
    el.className = "save error";
  }
}

async function api(method, path, body) {
  const res = await fetch(API_BASE + path, {
    method,
    headers: { "Content-Type": "application/json" },
    body: body === undefined ? undefined : JSON.stringify(body),
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(typeof data.detail === "string" ? data.detail : "Request failed");
  return data;
}

// One-field auto-save used by every inline editor.
async function saveField(entity, id, field, value) {
  setSave("saving");
  try {
    const path = entity === "profile" ? "/profile" : `/${entity}/${id}`;
    const row = await api("PATCH", path, { [field]: value });
    setSave("saved");
    return row;
  } catch (e) {
    setSave("error", e.message);
    throw e;
  }
}
