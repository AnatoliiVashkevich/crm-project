// app.js - tree, workspace views, inline editing, 2-tap delete
const $ = id => document.getElementById(id);
const esc = s => String(s ?? "").replace(/[&<>"']/g, c =>
  ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
const usd = n => Number(n || 0).toLocaleString("en-US", { style: "currency", currency: "USD" });
const STATUSES = ["Scheduled", "In Progress", "Completed", "Canceled"];
const TABS = [["visits", "Visits & Plan"], ["estimate", "Estimate"], ["receipts", "Receipts"], ["invoices", "Invoices"]];
const LATER = { receipts: "Receipts & photos — coming in Step 6." };

let tree = [], filter = "all", sel = null, projectTab = "visits", cur = null;
const expanded = new Set();

// ---------- inline editing (click text -> edit -> auto-save) ----------
function ed(entity, id, field, value, o = {}) {
  const empty = value === null || value === undefined || value === "";
  const shown = empty ? `<span class="ph">${esc(o.ph || "+ add")}</span>` : esc(value);
  const opts = o.opts ? ` data-opts="${esc(o.opts.join("|"))}"` : "";
  return `<span class="ed" data-entity="${entity}" data-id="${id}" data-field="${field}" ` +
         `data-type="${o.type || "text"}" data-value="${esc(value ?? "")}"${opts}>${shown}</span>`;
}

function paint(span, v) {
  span.innerHTML = v === "" || v == null ? `<span class="ph">+ add</span>` : esc(v);
}

function startEdit(span) {
  const { type, value, opts } = span.dataset;
  let input;
  if (type === "select") {
    input = document.createElement("select");
    opts.split("|").forEach(o => {
      const op = document.createElement("option");
      op.value = op.textContent = o;
      if (o === value) op.selected = true;
      input.appendChild(op);
    });
  } else if (type === "textarea") {
    input = document.createElement("textarea");
    input.rows = 3;
    input.value = value;
  } else {
    input = document.createElement("input");
    input.type = type;
    input.value = value;
    if (type === "number") input.step = "0.01";
  }
  input.className = "ed-input";
  span.textContent = "";
  span.appendChild(input);
  input.focus();
  if (type === "text" || type === "number") input.select();

  let done = false;
  const finish = async commit => {
    if (done) return;
    done = true;
    const v = input.value;
    if (!commit || v === value) return paint(span, value);
    try {
      await saveField(span.dataset.entity, span.dataset.id, span.dataset.field, v);
      span.dataset.value = v;
      paint(span, v);
      afterSave(span.dataset.entity, span.dataset.field);
    } catch {
      paint(span, value);
    }
  };
  input.addEventListener("blur", () => finish(true));
  input.addEventListener("keydown", ev => {
    if (ev.key === "Escape") finish(false);
    else if (ev.key === "Enter" && type !== "textarea") input.blur();
  });
  if (type === "select") input.addEventListener("change", () => input.blur());

  if (span.dataset.field === "street" && ["clients", "projects"].includes(span.dataset.entity)) {
    attachAddress(input, span, async a => {
      done = true;   // picking a suggestion replaces the typed text; skip the normal blur-save
      try {
        await saveFields(span.dataset.entity, span.dataset.id,
          { street: a.street, city: a.city, state: a.state, zip: a.zip });
        showWorkspace();
      } catch {
        paint(span, value);
      }
    });
  }
}

// Address autocomplete: type in a street field -> suggestions fill street, city, state and ZIP at once.
function attachAddress(input, span, onPick) {
  const box = document.createElement("div");
  box.className = "addr-box";
  span.appendChild(box);
  let timer, seq = 0;
  input.addEventListener("input", () => {
    clearTimeout(timer);
    const q = input.value.trim();
    if (q.length < 4) { box.innerHTML = ""; return; }
    timer = setTimeout(async () => {
      const mine = ++seq;
      try {
        const list = await api("GET", `/address-search?q=${encodeURIComponent(q)}`);
        if (mine !== seq) return;   // a newer keystroke already started another search
        box.innerHTML = "";
        list.forEach(a => {
          const item = document.createElement("div");
          item.className = "addr-item";
          item.textContent = a.label;
          // mousedown + preventDefault keeps focus in the input, so blur-save doesn't fire first
          item.addEventListener("mousedown", ev => { ev.preventDefault(); onPick(a); });
          box.appendChild(item);
        });
      } catch {
        box.innerHTML = "";
      }
    }, 350);
  });
}

function afterSave(entity, field) {
  if (["clients", "projects", "visits"].includes(entity) && ["name", "visit_date", "status"].includes(field)) loadTree();
  if (entity === "invoices") loadTree();   // debt badges
  if (["name", "time_spent", "status", "labor_amount", "materials_amount",
       "estimate_fixed", "estimate_rate", "estimate_hours"].includes(field)) showWorkspace();
}

// ---------- inline delete: 1st tap arms (3 s), 2nd tap deletes ----------
function handleDelete(btn) {
  if (btn.dataset.armed) {
    clearTimeout(btn._t);
    return doDelete(btn.dataset.entity, btn.dataset.id, btn.dataset.backType, btn.dataset.backId);
  }
  btn.dataset.armed = "1";
  btn.dataset.label = btn.textContent;
  btn.textContent = "Confirm Delete";
  btn.classList.add("armed");
  btn._t = setTimeout(() => {
    delete btn.dataset.armed;
    btn.textContent = btn.dataset.label;
    btn.classList.remove("armed");
  }, 3000);
}

async function doDelete(entity, id, backType, backId) {
  setSave("saving");
  try {
    await api("DELETE", `/${entity}/${id}`);
    setSave("saved");
  } catch (e) {
    return setSave("error", e.message);
  }
  sel = backType ? { type: backType, id: backId } : (sel && sel.id === id ? null : sel);
  await loadTree();
  await showWorkspace();
}

// ---------- navigation tree ----------
async function loadTree() {
  tree = await api("GET", "/tree");
  renderTree();
}

const badge = debt => debt > 0 ? `<span class="badge">🔴 ${usd(debt)}</span>` : "";
const isSel = (type, id) => sel && sel.type === type && sel.id === id ? "active" : "";
const caret = id => `<span class="caret" data-toggle="${id}">${expanded.has(id) ? "▼" : "▶"}</span>`;

// Date rules: Scheduled / In Progress visits dated today or later are bold;
// 0-3 days away (today included) they also get a blue frame. Completed, Canceled or past dates: neither.
function visitClass(v) {
  let cls = "st-" + v.status.toLowerCase().replace(" ", "-");
  if (v.status === "Scheduled" || v.status === "In Progress") {
    const [y, m, d] = v.visit_date.split("-").map(Number);
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const days = Math.round((new Date(y, m - 1, d) - today) / 86400000);
    if (days >= 0) cls += " vbold" + (days <= 3 ? " vsoon" : "");
  }
  return cls;
}

// Status switch in 1 tap: four buttons instead of a dropdown.
const statusChips = v => `<div class="seg">${STATUSES.map(s =>
  `<button class="seg-btn ${v.status === s ? "active" : ""}" data-status="${s}" data-id="${v.id}">${s}</button>`
).join("")}</div>`;

async function setStatus(id, status) {
  try {
    await saveField("visits", id, "status", status);
    await loadTree();
    await showWorkspace();
  } catch { /* the error is already shown in the save indicator */ }
}

function visitNode(v) {
  return `<div class="node visit ${visitClass(v)} ${isSel("visit", v.id)}" data-type="visit" data-id="${v.id}">` +
         `📅 ${esc(v.visit_date)} · ${esc(v.status)}</div>`;
}

function projectNode(p) {
  const kids = expanded.has(p.id)
    ? `<div class="children">${p.visits.map(visitNode).join("")}` +
      `<button class="add" data-add="visit" data-parent="${p.id}">+ Visit</button></div>`
    : "";
  return `<div class="node project ${isSel("project", p.id)}" data-type="project" data-id="${p.id}">` +
         `${caret(p.id)}<span class="label">📁 ${esc(p.name || "(no name)")}</span>${badge(p.debt)}</div>${kids}`;
}

function renderTree() {
  const list = filter === "unpaid" ? tree.filter(c => c.debt > 0) : tree;
  $("tree").innerHTML = list.length ? list.map(c => {
    const kids = expanded.has(c.id)
      ? `<div class="children">${c.projects.map(projectNode).join("")}` +
        `<button class="add" data-add="project" data-parent="${c.id}">+ Project</button></div>`
      : "";
    return `<div class="node client ${isSel("client", c.id)}" data-type="client" data-id="${c.id}">` +
           `${caret(c.id)}<span class="label">${esc(c.name || "(no name)")}</span>${badge(c.debt)}</div>${kids}`;
  }).join("") : `<div class="empty small">${filter === "unpaid" ? "No unpaid clients 🎉" : "No clients yet."}</div>`;
}

function toggle(id) {
  expanded.has(id) ? expanded.delete(id) : expanded.add(id);
  renderTree();
}

async function select(type, id) {
  sel = { type, id };
  if (type !== "visit") expanded.add(id);
  renderTree();
  await showWorkspace();
}

async function createChild(kind, parentId) {
  setSave("saving");
  try {
    let row;
    if (kind === "client") row = await api("POST", "/clients", { name: "New Client" });
    else if (kind === "project") row = await api("POST", "/projects", { client_id: parentId, name: "New Project" });
    else row = await api("POST", "/visits", { project_id: parentId });
    setSave("saved");
    if (parentId) expanded.add(parentId);
    await loadTree();
    await select(kind, row.id);
    if (kind !== "visit") document.querySelector('.ed[data-field="name"]')?.click(); // jump straight into naming
  } catch (e) {
    setSave("error", e.message);
  }
}

// ---------- estimate + invoices ----------
async function setEstMode(mode) {
  const p = cur.project;
  const fields = { estimate_mode: mode || null };
  if (mode === "hourly" && !Number(p.estimate_rate) && cur.default_rate) fields.estimate_rate = cur.default_rate;
  try { await saveFields("projects", p.id, fields); await showWorkspace(); } catch { /* shown in indicator */ }
}

async function fillEstimate() {   // Planned Work -> Estimate
  const text = cur.visits.filter(v => v.status !== "Canceled" && (v.planned_work || "").trim())
    .map(v => v.planned_work.trim()).join("\n");
  if (!text) return alert("No Planned Work found in this project's visits yet.");
  try { await saveField("projects", cur.project.id, "estimate_description", text); await showWorkspace(); } catch { /* shown */ }
}

async function setInvStatus(id, status) {   // [ Unpaid ] <-> [ Paid ]
  try { await saveField("invoices", id, "status", status); await loadTree(); await showWorkspace(); } catch { /* shown */ }
}

async function createInvoice(visitId) {
  setSave("saving");
  try {
    await api("POST", `/visits/${visitId}/invoice`);
    setSave("saved");
    await loadTree();
    await showWorkspace();
  } catch (e) {
    setSave("error", e.message);
    alert(e.message);
  }
}

function estimateTab(d) {
  const p = d.project, mode = p.estimate_mode || "";
  const chips = [["", "No estimate"], ["fixed", "Fixed Price"], ["hourly", "Hourly Rate"]].map(([k, label]) =>
    `<button class="seg-btn ${mode === k ? "active" : ""}" data-est-mode="${k}">${label}</button>`).join("");
  let fields = `<p class="muted">The estimate is optional. Without one, invoices use actual visit hours × your default rate (My Profile).</p>`;
  if (mode === "fixed") {
    fields = `<div class="grid">${row("Fixed Price ($)", ed("projects", p.id, "estimate_fixed", p.estimate_fixed, { type: "number", ph: "0.00" }))}</div>
      <p class="muted">A fixed price is billed once, on the project's first invoice.</p>`;
  } else if (mode === "hourly") {
    const total = Number(p.estimate_rate || 0) * Number(p.estimate_hours || 0);
    fields = `<div class="grid">
      ${row("Rate ($/h)", ed("projects", p.id, "estimate_rate", p.estimate_rate, { type: "number", ph: "0.00" }))}
      ${row("Est. Hours", ed("projects", p.id, "estimate_hours", p.estimate_hours, { type: "number", ph: "0" }))}
      ${row("Estimated Total", `<b>${usd(total)}</b>`)}</div>
      <p class="muted">Invoices bill actual visit hours × this rate.</p>`;
  }
  const desc = mode
    ? `<div class="grid">${row("Estimate Description", ed("projects", p.id, "estimate_description", p.estimate_description, { type: "textarea", ph: "+ describe the work" }), "wide")}</div>
       <button class="btn" data-fill-estimate>↻ Fill from Planned Work</button>`
    : "";
  return `<div class="seg">${chips}</div>${fields}${desc}`;
}

const invStatus = i => `<div class="seg">${["Unpaid", "Paid"].map(s =>
  `<button class="seg-btn inv-${s.toLowerCase()} ${i.status === s ? "active" : ""}" data-inv-status="${s}" data-id="${i.id}">${s}</button>`
).join("")}</div>`;

// "+ Create Invoice" for project / client pages: the invoice is created from the chosen visit (default: latest).
function invoiceCreator(visits, names = null) {
  const active = visits.filter(v => v.status !== "Canceled");
  if (!active.length) return `<p class="muted">Add a visit first: every invoice is created from a visit.</p>`;
  const latest = active[active.length - 1];   // visits arrive sorted by date
  const opts = active.map(v => `<option value="${v.id}" ${v === latest ? "selected" : ""}>` +
    `${esc((names ? names[v.project_id] + " · " : "") + v.visit_date + " · " + v.status)}</option>`).join("");
  return `<div class="creator">For visit: <select id="invVisitPick">${opts}</select>
    <button class="btn green" data-create-invoice-pick>+ Create Invoice</button></div>`;
}

function invoiceTable(list, visits = [], names = null) {
  if (!list.length) return `<div class="empty small">No invoices yet.</div>`;
  const vdate = id => {
    const v = visits.find(x => x.id === id);
    return v ? (names ? names[v.project_id] + " · " : "") + v.visit_date : "";
  };
  const rows = list.map(i => `<tr>
    <td>${esc(i.invoice_number)}</td>
    <td>${ed("invoices", i.id, "invoice_date", i.invoice_date, { type: "date" })}</td>
    ${visits.length ? `<td>${esc(vdate(i.visit_id))}</td>` : ""}
    <td>${ed("invoices", i.id, "description", i.description, { type: "textarea", ph: "+ add description" })}</td>
    <td>${ed("invoices", i.id, "labor_amount", i.labor_amount, { type: "number" })}</td>
    <td>${ed("invoices", i.id, "materials_amount", i.materials_amount, { type: "number" })}</td>
    <td><b>${usd(i.total)}</b></td>
    <td>${invStatus(i)}${i.status === "Paid" ? `<div class="muted">Paid on ${ed("invoices", i.id, "paid_date", i.paid_date, { type: "date" })}</div>` : ""}</td>
    <td class="act"><a class="btn" href="/api/invoices/${i.id}/pdf" target="_blank">View</a>
      <a class="btn" href="/api/invoices/${i.id}/pdf?download=1">Download PDF</a>
      <button class="del-btn" title="Delete invoice" data-entity="invoices" data-id="${i.id}">🗑</button></td></tr>`).join("");
  return `<table><thead><tr><th>#</th><th>Date</th>${visits.length ? "<th>Visit</th>" : ""}<th>Description</th>
    <th>Labor $</th><th>Materials $</th><th>Total</th><th>Status</th><th></th></tr></thead><tbody>${rows}</tbody></table>`;
}

// ---------- workspace views ----------
const row = (label, html, cls = "") => `<div class="field ${cls}"><label>${label}</label><div>${html}</div></div>`;

function viewProfile(p) {
  $("crumbs").textContent = "My Profile";
  return `<h2>My Profile</h2><div class="grid">
    ${row("Company / LLC Name", ed("profile", 1, "company_name", p.company_name))}
    ${row("Phone", ed("profile", 1, "phone", p.phone))}
    ${row("Email", ed("profile", 1, "email", p.email))}
    ${row("Business Address", ed("profile", 1, "business_address", p.business_address))}
    ${row("Payment Details", ed("profile", 1, "payment_details", p.payment_details, { type: "textarea" }))}
    ${row("Default Hourly Rate ($)", ed("profile", 1, "default_hourly_rate", p.default_hourly_rate, { type: "number", ph: "0" }))}
  </div><p class="muted">Used in the header of every Estimate and Invoice.</p>`;
}

const CLIENT_TABS = [["visits", "Visits & Plan"], ["receipts", "Receipts"], ["invoices", "Invoices"]];

function viewClient(d) {
  const c = d.client;
  const names = Object.fromEntries(d.projects.map(p => [p.id, p.name]));
  $("crumbs").textContent = c.name;
  const f = (label, field, o) => row(label, ed("clients", c.id, field, c[field], o));
  const tab = CLIENT_TABS.some(([k]) => k === projectTab) ? projectTab : "visits";
  const tabs = CLIENT_TABS.map(([k, label]) =>
    `<button class="tab ${tab === k ? "active" : ""}" data-tab="${k}">${label}</button>`).join("");
  const projectOptions = d.projects.map(p => `<option value="${p.id}">${esc(p.name)}</option>`).join("");
  const body = tab === "visits" ? visitsTable(d.visits, { names, projectOptions })
    : tab === "invoices" ? invoiceTable(d.invoices, d.visits, names) + invoiceCreator(d.visits, names)
    : `<div class="empty small">${LATER.receipts}</div>`;
  return `<h2>${ed("clients", c.id, "name", c.name, { ph: "+ add name" })} ${badge(d.debt)}</h2>
    <div class="grid">${f("Phone", "phone")}${f("Email", "email")}
    ${row("Address", ["street", "city", "state", "zip"].map(k => ed("clients", c.id, k, c[k], { ph: "+ " + k })).join(", "), "wide")}
    ${f("Notes", "notes", { type: "textarea" })}</div>
    <div class="muted">⏱ Total hours: <b>${d.total_hours}</b> · ${d.projects.length} project(s)
      · <button class="btn green" data-add="project" data-parent="${c.id}">+ Project</button></div>
    <div class="tabs">${tabs}</div>${body}
    <div class="actions"><button class="del-btn" data-entity="clients" data-id="${c.id}">🗑 Delete Client</button></div>`;
}

// One visits table for every level. names = {projectId: name} adds a Project column (client page).
function visitsTable(visits, o = {}) {
  const rows = visits.map(v => `<tr class="${visitClass(v)}">
      ${o.names ? `<td>${esc(o.names[v.project_id])}</td>` : ""}
      <td>${ed("visits", v.id, "visit_date", v.visit_date, { type: "date" })}</td>
      <td>${statusChips(v)}</td>
      <td>${ed("visits", v.id, "time_spent", v.time_spent, { type: "number", ph: "0" })}</td>
      <td>${ed("visits", v.id, "planned_work", v.planned_work, { type: "textarea", ph: "+ add plan" })}</td>
      <td class="act"><button class="btn" data-open="visit" data-id="${v.id}">Open</button>
        <button class="del-btn" title="Delete visit" data-entity="visits" data-id="${v.id}">🗑</button></td></tr>`).join("");
  const cols = o.names ? 6 : 5;
  const add = o.addTo
    ? `<button class="btn green" data-add="visit" data-parent="${o.addTo}">+ Visit</button>`
    : (o.projectOptions
        ? `<select id="addVisitProject">${o.projectOptions}</select> <button class="btn green" data-add-visit-pick>+ Visit</button>`
        : `<span class="muted">Add a project first.</span>`);
  return `<table><thead><tr>${o.names ? "<th>Project</th>" : ""}<th>Date</th><th>Status</th><th>Hours</th><th>Planned Work</th><th></th></tr></thead>
    <tbody>${rows || `<tr><td colspan="${cols}" class="muted">No visits yet.</td></tr>`}</tbody></table>${add}`;
}

function viewProject(d) {
  const p = d.project, c = d.client;
  $("crumbs").textContent = `${c.name} / ${p.name}`;
  const tabs = TABS.map(([k, label]) =>
    `<button class="tab ${projectTab === k ? "active" : ""}" data-tab="${k}">${label}</button>`).join("");
  const body = projectTab === "visits" ? visitsTable(d.visits, { addTo: p.id })
    : projectTab === "estimate" ? estimateTab(d)
    : projectTab === "invoices" ? invoiceTable(d.invoices, d.visits) + invoiceCreator(d.visits)
    : `<div class="empty small">${LATER[projectTab]}</div>`;
  return `<h2>${esc(c.name)} / ${ed("projects", p.id, "name", p.name, { ph: "+ add name" })} ${badge(d.debt)}</h2>
    <div class="muted">📍 ${ed("projects", p.id, "street", p.street, { ph: "+ street" })},
      ${ed("projects", p.id, "city", p.city, { ph: "+ city" })},
      ${ed("projects", p.id, "state", p.state, { ph: "+ state" })}
      ${ed("projects", p.id, "zip", p.zip, { ph: "+ zip" })} · ⏱ Total hours: <b>${d.total_hours}</b></div>
    <div class="tabs">${tabs}</div>${body}
    <div class="actions"><button class="del-btn" data-entity="projects" data-id="${p.id}"
      data-back-type="client" data-back-id="${c.id}">🗑 Delete Project</button></div>`;
}

function viewVisit(d) {
  const v = d.visit, p = d.project, c = d.client;
  $("crumbs").textContent = `${c.name} / ${p.name} / ${v.visit_date}`;
  const addr = [p.street, p.city, p.state, p.zip].filter(Boolean).join(", ") ||
               [c.street, c.city, c.state, c.zip].filter(Boolean).join(", ") || "no address";
  return `<h2>Visit · ${ed("visits", v.id, "visit_date", v.visit_date, { type: "date" })}
      </h2><div class="status-row">${statusChips(v)}</div>
    <div class="muted">${esc(c.name)} · ${esc(c.phone || "no phone")} · ${esc(c.email || "no email")} · ${esc(addr)}
      · <button class="link" data-open="project" data-id="${p.id}">← back to project</button></div>
    <div class="grid">
      ${row("Time Spent (hours)", ed("visits", v.id, "time_spent", v.time_spent, { type: "number", ph: "0" }))}
      ${row("Planned Work", ed("visits", v.id, "planned_work", v.planned_work, { type: "textarea", ph: "+ add plan" }))}
    </div>
    <h3>Invoice</h3>${d.invoices.length ? invoiceTable(d.invoices) : ""}
    <div>${v.status === "Canceled"
      ? `<span class="muted">Canceled visits can’t be invoiced.</span>`
      : `<button class="btn green" data-create-invoice="${v.id}">+ Create Invoice</button>`}</div>
    <div class="empty small">Photos — Step 6.</div>
    <div class="actions"><button class="del-btn" data-entity="visits" data-id="${v.id}"
      data-back-type="project" data-back-id="${p.id}">🗑 Delete Visit</button></div>`;
}

async function showWorkspace() {
  const ws = $("workspace");
  try {
    if (!sel) {
      $("crumbs").textContent = "";
      ws.innerHTML = `<div class="empty">Select or create a client on the left.</div>`;
    } else if (sel.type === "profile") ws.innerHTML = viewProfile(await api("GET", "/profile"));
    else if (sel.type === "report") {
      $("crumbs").textContent = "Income & Expense Report";
      ws.innerHTML = `<div class="empty">Income &amp; Expense Report — coming in Step 7.</div>`;
    } else if (sel.type === "client") ws.innerHTML = viewClient(await api("GET", `/clients/${sel.id}`));
    else if (sel.type === "project") { cur = await api("GET", `/projects/${sel.id}`); ws.innerHTML = viewProject(cur); }
    else ws.innerHTML = viewVisit(await api("GET", `/visits/${sel.id}`));
  } catch (e) {
    ws.innerHTML = `<div class="empty error">${esc(e.message)}</div>`;
  }
}

// ---------- one delegated click handler for the whole page ----------
document.addEventListener("click", e => {
  const t = e.target;
  let el;
  if ((el = t.closest(".ed"))) { if (!el.querySelector(".ed-input")) startEdit(el); return; }
  if ((el = t.closest("[data-status]"))) return setStatus(el.dataset.id, el.dataset.status);
  if ((el = t.closest("[data-inv-status]"))) return setInvStatus(el.dataset.id, el.dataset.invStatus);
  if ((el = t.closest("[data-est-mode]"))) return setEstMode(el.dataset.estMode);
  if ((el = t.closest("[data-fill-estimate]"))) return fillEstimate();
  if ((el = t.closest("[data-create-invoice]"))) return createInvoice(el.dataset.createInvoice);
  if (t.closest("[data-create-invoice-pick]")) return createInvoice($("invVisitPick").value);
  if (t.closest("[data-add-visit-pick]")) return createChild("visit", $("addVisitProject").value);
  if ((el = t.closest(".del-btn"))) return handleDelete(el);
  if ((el = t.closest("[data-add]"))) return createChild(el.dataset.add, el.dataset.parent);
  if ((el = t.closest("[data-open]"))) return select(el.dataset.open, el.dataset.id);
  if ((el = t.closest("[data-toggle]"))) return toggle(el.dataset.toggle);
  if ((el = t.closest("[data-tab]"))) { projectTab = el.dataset.tab; return showWorkspace(); }
  if ((el = t.closest("[data-filter]"))) {
    filter = el.dataset.filter;
    document.querySelectorAll("[data-filter]").forEach(b => b.classList.toggle("active", b === el));
    return renderTree();
  }
  if ((el = t.closest("[data-view]"))) { sel = { type: el.dataset.view }; renderTree(); return showWorkspace(); }
  if ((el = t.closest(".node"))) return select(el.dataset.type, el.dataset.id);
});

loadTree().then(showWorkspace).catch(e => {
  $("tree").innerHTML = `<div class="empty small error">${esc(e.message)}</div>`;
});
